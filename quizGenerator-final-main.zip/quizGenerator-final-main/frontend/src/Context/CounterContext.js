import { createContext } from "react";
export let CounterContext=createContext()